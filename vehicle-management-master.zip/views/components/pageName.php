<?php
    /* $_SERVER['PHP_SELF'] */